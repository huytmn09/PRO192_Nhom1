/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Acer
 */
public class menuUser {

    public static double balance;

    public menuUser() {
    }

    /*
    Method to display account's balance
    */
    public static double getBalance() throws SQLException, ClassNotFoundException {
        Connection conn = DConection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT Balance from khachhang where CardID='" + login.CardID + "'");// SQL code to get Balance from an account
        if (rs.next()) {
            menuUser.balance = rs.getDouble(1);
            //get balance
        }
        return balance;
    }
    /*
    Method for deposit
    */
    public void deposit(double amountDeposit) throws SQLException, ClassNotFoundException {
        Connection conn = DConection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT Balance FROM khachhang WHERE CardID='" + login.CardID + "'");
        //Get Balance from an account
        double currentMoney = 0;
        if (rs.next()) {
            currentMoney = rs.getDouble(1);
            //get balance
        }
        double add = currentMoney + amountDeposit; //Add deposit to balance
        Connection conn1 = DConection.getConnection();
        Statement stmt1 = conn1.createStatement();
        stmt1.executeUpdate("UPDATE khachhang SET Balance = " + add + " WHERE CardID='" + login.CardID + "'"); //Update balance
    }
    
    /*
    Method for withdrawl 
    */
    public void withdrawl(double amountWithdrawl) throws SQLException, ClassNotFoundException {
        Connection conn = DConection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT Balance FROM khachhang WHERE CardID='" + login.CardID + "'");

        double currentMoney = 0;
        if (rs.next()) {
            currentMoney = rs.getDouble(1);
        }
        double add = currentMoney - amountWithdrawl;
        Connection conn1 = DConection.getConnection();
        Statement stmt1 = conn1.createStatement();
        stmt1.executeUpdate("UPDATE khachhang SET Balance = " + add + " WHERE CardID='" + login.CardID + "'");
        //Update balance by minus for amountWithdrawl
    }
    /*
    Method to changePIN
    */
    public void changePassword(int newPin) throws SQLException, ClassNotFoundException {

        Connection conn = DConection.getConnection();
        Statement stmt = conn.createStatement();
        stmt.executeUpdate("UPDATE khachhang SET PIN = " + newPin + " WHERE CardID='" + login.CardID + "'");
        //Update PIN by SQL code to MySQL
    }
}
