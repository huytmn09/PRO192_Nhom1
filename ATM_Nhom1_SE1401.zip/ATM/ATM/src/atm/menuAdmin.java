/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Acer
 */
class depositException extends Exception {

    public depositException() {
    }

}

class withdrawlException extends Exception {

    public withdrawlException() {
    }

}

public class menuAdmin {

    static double amountDepositLimit = 25000; //amount of deposit limit
    static double amountWithdrawlLimit = 25000; //amount of withdrawl limit
    static int maxTimeOfDeposit = 5; //max time of deposit
    static int maxTimeOfWithdrawl = 5; //max time of withdrawl
    //declare variable and Intialize it
    public menuAdmin() {
    }

    
    /*
    Methods to check amount of deposit and time of deposit
    */
    public static void checkDeposit(double amountDeposit, int timeOfDeposit) throws depositException {
        if (amountDeposit <= 0 || amountDeposit > amountDepositLimit || timeOfDeposit > maxTimeOfDeposit) { //Condition to check deposit
            throw new depositException();
        }

    }
   /*
    Method to check amount and times of withdrawl
    */ 
    
    public static void checkWithdrawl(double amountWithdrawl, int timeOfWithdrawl) throws withdrawlException {
        if (amountWithdrawl <= 0 || amountWithdrawl > amountWithdrawlLimit || timeOfWithdrawl > maxTimeOfWithdrawl) {//Condition to check withdrawl
            throw new withdrawlException();
        }
    }

    /*
    Method to change amount of deposit limit
    */
    public static void changeAmountDepositLimit(double newAmountDepositLimit) {
        if (newAmountDepositLimit <= 0) { //If amount of deposit limit smaller than 0 
            System.out.println("New Amount Deposit Limit must be greater than 0."); //annouce for user know
        } else {
            menuAdmin.amountDepositLimit = newAmountDepositLimit; //Else change the amount of deposit limit
            System.out.println("Success!"); //Success !!!
        }
    }
    /*
    Method to change amount of withdrawl limit
    */
    public static void changeAmountWithdrawlLimit(double newAmountWithdrawlLimit) {
        if (newAmountWithdrawlLimit <= 0) { //If amount of withdrawl limit smaller than 0
            System.out.println("New Amount Withdrawl Limit must be greater than 0."); //anounce for user know
        } else {
            menuAdmin.amountWithdrawlLimit = newAmountWithdrawlLimit; //Else change the amount of withdrawl
            System.out.println("Success!"); //Sucess!!!
        }
    }
    /*
    Method to change time of deposit
    */
    public static void changeMaxTimeOfDeposit(int newMaxTimeOfDeposit) {
        if (newMaxTimeOfDeposit <= 0) { //If time of deposits smaller than 0
            System.out.println("New Max Time Of Deposit must be greater than 0."); //annouce for user know
        } else {
            menuAdmin.maxTimeOfDeposit = newMaxTimeOfDeposit; //Else change time of deposit
            System.out.println("Success!"); //Success!!!
        }
    }
    /*
    Method to change time of withdrawl
    */
    public static void changeMaxTimeOfWithdrawl(int newMaxTimeOfWithdrawl) {
        if (newMaxTimeOfWithdrawl <= 0) { //If time of withdrawl smaller than 0
            System.out.println("New Max Time Of Withdrawl must be greater than 0."); //annouce for user know
        } else {
            menuAdmin.maxTimeOfWithdrawl = newMaxTimeOfWithdrawl; //Else change time  of withdrawl
            System.out.println("Success!");
        }
    }
    /*
    Method to change PIN code
    */
    public void changeAdminPin(int newPin) throws SQLException, ClassNotFoundException {
        Connection conn = DConection.getConnection();
        Statement stmt = conn.createStatement();
        stmt.executeUpdate("UPDATE khachhang SET PIN = " + newPin + " WHERE CardID='" + login.CardID + "'"); //Code SQL to change data
    }
    /*
    Method to diplay 5 time in historical transaction
    */
    public static void viewAccountInformation(String CardID, int status) throws SQLException, ClassNotFoundException {
        if (status == 0) {
            System.out.println("This card ID does not exist.");
        } else {
            Connection conn = DConection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM bang2 WHERE CardID='" + CardID + "' ORDER BY Date DESC LIMIT 5"); //Code SQL to find top 5 of transaction
            while (rs.next()) {
                System.out.println("Date: " + rs.getString(2));
                System.out.println("Name: " + rs.getString(3));
                System.out.println("Card ID: " + rs.getString(1));
                System.out.println("Amount of Transaction: " + rs.getString(4));
                System.out.println("Transaction: " + rs.getString(5));
                System.out.println("");
                //Print info of transactions 
            }
        }
    }
}
