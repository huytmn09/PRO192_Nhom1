/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import static atm.ATM.time;
import static java.lang.Integer.parseInt;
import java.sql.DriverManager;
import java.util.Scanner;

class DConection {//use to connect to mysql

    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/atm", "root", "");
        return con;
    }
}

class login {

    public static String CardID;//declare variable to store card id

    public login() {
    }
// input card id & pin, and if they are correct
    public static String loginUser() throws SQLException, NullPointerException, ClassNotFoundException {
        Connection conn = DConection.getConnection();
        Statement stmt = conn.createStatement();
        String status = "";
        Scanner input = new Scanner(System.in);
        System.out.println("Enter CARD ID:");
        CardID = input.nextLine();
        System.out.println("Enter PIN:");
        String Pin = input.nextLine();
        ResultSet rs = stmt.executeQuery("SELECT Role from khachhang where CardID='" + CardID + "' and PIN='" + Pin + "'");
        if (rs.next()) {
            status = rs.getString(1);
        }
        return status;
    }
}

/**
 *
 * @author Acer
 */
public class ATM {

    /**
     * @param args the command line arguments
     */
    public static String CardID;//card id of account
    public static String Pin;   //Pin of account
    public static int time = 0; // count time of withdrawl/deposit

    public static void main(String[] args) throws SQLException, depositException, NullPointerException, ClassNotFoundException {
        Scanner im = new Scanner(System.in);
        login status = new login();//create object belong to login class
        int choice;// is a choice of user & admin for their own menu
        String status1 = "";// use to store the role of account is 'user' or 'admin'
        //loop to the ATM always active
        do {
            //loop to check if id & pin is coorrect or not
            do {
                status1 = status.loginUser();
                if (status1.compareTo("") == 0) {
                    System.out.println("Wrong Card ID or wrong PIN!");
                }
            } while (status1.compareTo("") == 0);
            choice = 1;
            //if status1 is user, display the user menu
            if (status1.compareTo("user") == 0) {
                //display user menu
                while (choice >= 1 && choice < 5) {
                    System.out.printf("\n1. Deposit\n2. Withdrawl\n3.View balance\n4.Change PIN\n5. Exit\n");
                    choice = im.nextInt();
                    if (choice == 1) {// user deposit
                        //connect the sql query to database
                        Connection conn = DConection.getConnection();
                        Statement stmt = conn.createStatement();
                        ResultSet rs = stmt.executeQuery("SELECT COUNT(*) from bang2 WHERE CardID = '" + login.CardID + "' and Transaction = 'Deposit'");
                        if (rs.next()) {
                            time = parseInt(rs.getString(1));//get the time of deposit
                        }
                        menuAdmin obj = new menuAdmin();//create object belong to menuAdmin
                        System.out.println("How much do you want to Deposit?");
                        double money = im.nextDouble();
                        //check if user enter invalid input
                        try {
                            obj.checkDeposit(money, time);
                            menuUser obj2 = new menuUser();
                            obj2.deposit(money);
                            System.out.println(".....");
                            System.out.println("Success!");
                            reportAdmin obj3 = new reportAdmin();
                            obj3.depositReport(CardID, money);
                        } catch (Exception ex) {
                            System.out.println("Invalid input or Out of deposit time!");
                        }
                    }
                    if (choice == 2) {//user withdrawl                        
                        Connection conn = DConection.getConnection();
                        Statement stmt = conn.createStatement();
                        ResultSet rs = stmt.executeQuery("SELECT COUNT(*) from bang2 WHERE CardID = '" + login.CardID + "' and Transaction = 'Withdrawl'");
                        if (rs.next()) {
                            time = parseInt(rs.getString(1));
                        }
                        menuAdmin obj = new menuAdmin();//create object belong to menuAdmin
                        System.out.println("How much do you want to Withdrawl?");
                        double money = im.nextDouble();
                        //check if user enter invalid input
                        try {
                            obj.checkWithdrawl(money, time);
                            menuUser obj2 = new menuUser();
                            obj2.withdrawl(money);//call method withdrawl
                            System.out.println("Success!");
                            reportAdmin obj3 = new reportAdmin();
                            obj3.withdrawlReport(CardID, money);// call method withdrawlReport
                        } catch (Exception ex) {
                            System.out.println("Invalid input or Out of withdrawl times!");
                        }
                    }
                    if (choice == 3) {//show balance
                        menuUser obj = new menuUser();//create object belong to menuUser
                        System.out.print("Your balance is: " + obj.getBalance());//call methodd getBalance
                    }
                    if (choice == 4) {// change Pin
                        System.out.print("Please enter your old PIN: ");
                        int pin = im.nextInt();//pin that user input old pin
                        int status2 = 0;//use to check if old pin is true
                        Connection conn = DConection.getConnection();
                        Statement stmt = conn.createStatement();
                        ResultSet rs = stmt.executeQuery("SELECT Role FROM khachhang WHERE PIN=" + pin + " AND CardID='" + login.CardID + "'");
                        if (rs.next()) {
                            status2 = 1;
                        }
                        if (status2 == 1) {
                            String pin1 = "    ", pin2 = "    ";//pin1 store new piin input, pin2 store comfirm pin input
                            boolean match1 = false;//use to check with regular expression
                            int count = 0;//insert im.nextLine() for the first time
                            //check pin1,pin2 match & in format (####)
                            do {
                                System.out.print("Please enter your new PIN: ");
                                if (count == 0) {
                                    im.nextLine();
                                }
                                pin1 = im.nextLine();
                                match1 = pin1.matches("^\\d{4}");
                                System.out.print("Please comfirm your new PIN: ");
                                count++;
                                pin2 = im.nextLine();
                                if (pin1.compareTo(pin2) != 0 || match1 == false) {
                                    System.out.println("the PIN not matched or wrong format  (####)");

                                }
                            } while (pin1.compareTo(pin2) != 0 || match1 == false);
                            menuUser obj = new menuUser();
                            obj.changePassword(parseInt(pin1));// call method changePassword
                            System.out.println("Success!");
                        } else {
                            System.out.println("Wrong PIN");
                        }
                    }
                }
            } else {// if role='admin'
                choice = 1;
                //show the menu
                while (choice >= 1 && choice < 9) {
                    System.out.printf("\n1. Change Amount Deposit Limit\n2. Change Amount Withdrawl Limit\n3.Change Max Time Of Deposit\n4.Change Max Time Of Withdrawl\n");
                    System.out.printf("5. change PIN\n6. Show user's information\n7. View account transaction\n8. Create new account\n9. Exit\n");
                    System.out.print("Enter choice: ");
                    choice = im.nextInt();
                    if (choice == 5) {// change pin
                        System.out.print("Please enter your old PIN: ");
                        int pin = im.nextInt();//declare to store old pin
                        int status2 = 0; //to check old pin have or not have 
                        Connection conn = DConection.getConnection();
                        Statement stmt = conn.createStatement();
                        ResultSet rs = stmt.executeQuery("SELECT Role FROM khachhang WHERE PIN='" + pin + "' and CardID='" + login.CardID + "'");
                        if (rs.next()) {
                            status2 = 1;//if have statue =1
                        }
                        if (status2 == 1) {
                            String pin1 = "    ", pin2 = "    ";//declare pin1 to store new pin, pin2 to check pin1
                            boolean match1 = false;
                            int count = 0;//insert im.nextLine() for the first time
                            //loop to check pin1,pin2 match & in format (####) 
                            do {
                                System.out.print("Please enter your new PIN: ");
                                if (count == 0) {
                                    im.nextLine();
                                }
                                pin1 = im.nextLine();
                                match1 = pin1.matches("^\\d{4}");
                                System.out.print("Please comfirm your new PIN: ");
                                count++;
                                pin2 = im.nextLine();
                                if (pin1.compareTo(pin2) != 0 || match1 == false) {
                                    System.out.println("the PIN not matched or wrong format  (####)");

                                }
                            } while (pin1.compareTo(pin2) != 0 || match1 == false);
                            menuAdmin obj = new menuAdmin();
                            obj.changeAdminPin(parseInt(pin1));
                            System.out.println("Success!");
                        } else {
                            System.out.println("Wrong PIN");
                        }

                    }
                    if (choice == 1) {//change deposit limit
                        System.out.print("New Amount Deposit Limit: ");
                        int money = im.nextInt();//store new limit
                        menuAdmin obj = new menuAdmin();
                        obj.changeAmountDepositLimit(money);
                    }
                    if (choice == 2) {//change withdrawl limit
                        System.out.print("New Amount Withdrawl Limit: ");
                        double money = im.nextDouble();//store new limit
                        menuAdmin obj = new menuAdmin();
                        obj.changeAmountWithdrawlLimit(money);
                    }
                    if (choice == 3) {//change max time of deposit
                        System.out.print("New Max Time Of Deposit: ");
                        int time1 = im.nextInt();//store new time
                        menuAdmin obj = new menuAdmin();
                        obj.changeMaxTimeOfDeposit(time1);// coi lai cai time ma oi
                    }
                    if (choice == 4) {//change max time of withdrawl
                        System.out.print("New Max Time Of Withdrawl: ");
                        int time1 = im.nextInt();//store new time
                        menuAdmin obj = new menuAdmin();
                        obj.changeMaxTimeOfWithdrawl(time1);// coi lai cai time ma oi
                    }
                    if (choice == 6) {//show all user's information
                        reportAdmin obj = new reportAdmin();
                        obj.showAll();
                    }
                    if (choice == 7) {//view information base on card id
                        int status2 = 0;
                        menuAdmin obj = new menuAdmin();
                        System.out.println("Enter CARD ID:");
                        im.nextLine();
                        CardID = im.nextLine();
                        Connection conn = DConection.getConnection();
                        Statement stmt = conn.createStatement();
                        ResultSet rs = stmt.executeQuery("SELECT Role from khachhang where CardID='" + CardID + "'");
                        if (rs.next()) {
                            status2 = 1;
                        }
                        obj.viewAccountInformation(CardID, status2);
                    }
                    if (choice == 8) {//create new account
                        String newCardID = "";
                        boolean match2 = false;
                        int count1 = 0;
                        System.out.println("-----Create new account-------");
                        int check;//to check card id existed or not
                        //loop to create and check new card id
                        do {
                            check = 1;
                            do {
                                System.out.print("Enter cardID: ");
                                if (count1 == 0) {
                                    im.nextLine();
                                }
                                newCardID = im.nextLine();
                                match2 = newCardID.matches("^[0][6][7][7]\\d{8}$");
                                if (match2 == false) {
                                    System.out.println("Wrong format for card ID (0677########) ");
                                    count1++;
                                }
                            } while (!match2);
                            Connection conn = DConection.getConnection();
                            Statement stmt = conn.createStatement();
                            ResultSet rs = stmt.executeQuery("SELECT COUNT(CardID) FROM khachhang WHERE CardID='" + newCardID + "'");
                            if (rs.next()) {
                                if (rs.getInt(1) != 0) {
                                    check = 0;
                                    System.out.println("This Card ID is already Exist");
                                    count1++;
                                }
                            }
                        } while (check == 0);
                        System.out.print("Enter name: ");
                        String newName = im.nextLine();//store name of new account
                        String newGender;//store gender
                        //loop to check gender is male or female
                        do {
                            System.out.print("Enter your gender: ");
                            newGender = im.nextLine();
                            if (newGender.compareToIgnoreCase("Male") != 0 && newGender.compareToIgnoreCase("Female") != 0) {
                                System.out.println("Your gender is Male or Female!!! Please try again!!!");
                            }
                        } while (newGender.compareToIgnoreCase("Male") != 0 && newGender.compareToIgnoreCase("Female") != 0);
                        int newAge = 0;//store age
                        //loop to check age with format and age >0
                        do {
                            try {
                                System.out.print("Enter your age: ");
                                newAge = im.nextInt();
                                if (newAge <= 0) {
                                    System.out.println("Wrong age!!! Please try again!!!");
                                }
                            } catch (Exception ex) {
                                System.out.println("Wrong age!!! Please try again!!!");
                                im.nextLine();
                            }
                        } while (newAge <= 0);
                        String newPhone;//store phone number
                        boolean match = false;
                        int count2 = 0;
                        //loop check phone number with format
                        do {
                            System.out.print("Enter your phone number: ");
                            if (count2 == 0) {
                                im.nextLine();
                            }
                            newPhone = im.nextLine();
                            match = newPhone.matches("^[+][8][4]\\d{9}$");
                            if (match == false) {
                                System.out.println("Wrong format for phone number!!!Please enter base on (+84#########) format");
                                count2++;
                            }
                        } while (!match);
                        String pin1 = "    ", pin2 = "    ";//store new pin and checkfor new pin
                        boolean match1 = false;
                        //loop to check new pin with format
                        do {
                            System.out.print("Please enter your new PIN: ");
                            pin1 = im.nextLine();
                            match1 = pin1.matches("^\\d{4}");
                            System.out.print("Please comfirm your new PIN: ");
                            pin2 = im.nextLine();
                            if (pin1.compareTo(pin2) != 0 || match1 == false) {
                                System.out.println("the PIN not matched or wrong format  (####)");
                            }
                        } while (pin1.compareTo(pin2) != 0 || match1 == false);
                        double newBalance = -1;//store balance of new user
                        //loop to check balance>0
                        do {
                            try {
                                System.out.print("Enter balance: ");
                                newBalance = im.nextDouble();
                                if (newBalance < 0) {
                                    System.out.println("Wrong balance!!! Please try again!!!");
                                }
                            } catch (Exception ex) {
                                System.out.println("Wrong balance!!! Please try again!!!");
                                im.nextLine();
                            }
                        } while (newBalance < 0);
                        Connection conn1 = DConection.getConnection();
                        Statement stmt1 = conn1.createStatement();
                        stmt1.executeUpdate("INSERT INTO khachhang (FullName,Gender,Age,PhoneNumber,Role,CardID,Pin,Balance) VALUES ('"+newName+"','"+newGender+"',"+newAge+",'"+newPhone+"','user','"+newCardID+"',"+pin1+","+newBalance+")");
                        System.out.println("Success");
                    }
                }
            }
        } while (true);
    }
}
