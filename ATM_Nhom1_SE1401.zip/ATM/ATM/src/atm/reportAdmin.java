/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

/**
 *
 * @author Acer
 */
public class reportAdmin {
    public static String fname;
    /*
    Method to add deposit history
    */
    public static void depositReport(String CardID, double amountDeposit) throws SQLException, ClassNotFoundException {
        Connection conn = DConection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT FullName from khachhang where CardID='"+login.CardID+"'");        
        if (rs.next()) {
            reportAdmin.fname = rs.getString(1);
        }
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"); //Get time of deposit
        LocalDateTime now = LocalDateTime.now(); //Get system time
        Connection conn1 = DConection.getConnection();
        Statement stmt1 = conn1.createStatement();
        stmt1.executeUpdate("INSERT INTO bang2 (CardID,Date,FullName,Balance,Transaction) VALUES ('"+login.CardID+"','"+dtf.format(now)+"','"+reportAdmin.fname+"',"+amountDeposit+",'Deposit')");        
        //Code SQL to add new deposit history
    }
    /*
    Method to add new withdrawl history
    */
    public static void withdrawlReport(String CardID, double amountWithdrawl) throws SQLException, ClassNotFoundException {
        Connection conn = DConection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT FullName from khachhang where CardID='"+login.CardID+"'");        
        if (rs.next()) {
            reportAdmin.fname = rs.getString(1);
        }
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        Connection conn1 = DConection.getConnection();
        Statement stmt1 = conn1.createStatement();
        stmt1.executeUpdate("INSERT INTO bang2 (CardID,Date,FullName,Balance,Transaction) VALUES ('"+login.CardID+"','"+dtf.format(now)+"','"+reportAdmin.fname+"',"+amountWithdrawl+",'Withdrawl')");        
        //Add new withdrawl history
    }
    /*
    Method to show all info
    */
    public static void showAll() throws SQLException, ClassNotFoundException {
        Connection conn = DConection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("select * from khachhang WHERE Role = 'user'"); //Get info of user from database
        while (rs.next()) {
            System.out.println("Name: "+rs.getString(1));
            System.out.println("Card ID: "+rs.getString(6));
            System.out.println("Gender: "+rs.getString(2));
            System.out.println("Age: "+rs.getString(3));
            System.out.println("Phone number: "+rs.getString(4));
            System.out.println("Balnce: "+rs.getString(8));
            System.out.println("");
            //Display all user info
        }
    }
}
